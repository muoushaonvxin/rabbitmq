#!/bin/sh -e
make -C $(dirname $0) test
